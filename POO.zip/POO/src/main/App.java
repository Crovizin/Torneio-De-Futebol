package main;

import model.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

public class App {
    public static void main(String[] args) {
        List<Time> listaDeTimes = new ArrayList<>();

        listaDeTimes.add(new Time("Mixto", 1)); 
        listaDeTimes.add(new Time("Paysandu", 2));
        listaDeTimes.add(new Time("Flamengo", 3));
        listaDeTimes.add(new Time("Real Madrid", 4));
        listaDeTimes.add(new Time("Chapada FC", 5)); 
        listaDeTimes.add(new Time("Fenerbahce", 6));
        listaDeTimes.add(new Time("Al-Nasrr", 7));
        listaDeTimes.add(new Time("Inter Miami", 8));
        listaDeTimes.add(new Time("Votuporangense", 9)); 
        listaDeTimes.add(new Time("Milan", 10));
        listaDeTimes.add(new Time("Aguia de Maraba", 11));
        listaDeTimes.add(new Time("Bodø/Glimt", 12));
        listaDeTimes.add(new Time("Clube Brugge", 13)); 
        listaDeTimes.add(new Time("Cuiaba", 14));
        listaDeTimes.add(new Time("Barcelona", 15));
        listaDeTimes.add(new Time("PSV", 16));
        listaDeTimes.add(new Time("Ajax", 17));
        listaDeTimes.add(new Time("Napoli", 18));
        listaDeTimes.add(new Time("Juventus", 19));
        listaDeTimes.add(new Time("Manchester City", 20));
        listaDeTimes.add(new Time("Tottenham", 21));
        listaDeTimes.add(new Time("Liverpool", 22));
        listaDeTimes.add(new Time("Caceres", 23));
        listaDeTimes.add(new Time("Madureira", 24));
        listaDeTimes.add(new Time("Bangu", 25));
        listaDeTimes.add(new Time("Volta Redonda", 26));
        listaDeTimes.add(new Time("Inter de Milao", 27));
        listaDeTimes.add(new Time("PSG", 28));
        listaDeTimes.add(new Time("Bayern de Munique", 29));
        listaDeTimes.add(new Time("Borussia Dortmund", 30));
        listaDeTimes.add(new Time("Arsenal", 31));
        listaDeTimes.add(new Time("Libolo", 32));
        
        System.out.println("Total de times criados: " + listaDeTimes.size());
    }
}

// Supondo que 'todosTimes' é a sua List<Time>
public void mostrarTimesOrdenados() {
    // 1. Ordena a lista usando os critérios do RF3 
    todosTimes.sort(Comparator.comparingInt(Time::getPontos)
                              .thenComparingInt(Time::getRankingCMD)
                              .reversed()); // 'reversed' para ficar do maior para o menor

    // 2. Comando para imprimir cada time da lista 
    System.out.println("--- TABELA DO TORNEIO ---");
    for (Time t : todosTimes) {
        System.out.println("Nome: " + t.getNome() + 
                           " | Pontos: " + t.getPontos() + 
                           " | Ranking CMF: " + t.getRankingCMD());
    }
}
