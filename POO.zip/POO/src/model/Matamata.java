package model;

import java.util.ArrayList;
import java.util.List;

public class Matamata {

    private String faseAtual;
    private List<Time> classificados;
    
    public Matamata(String faseAtual){

        this.faseAtual = faseAtual;
        this.classificados = new ArrayList<>();
    }
}
