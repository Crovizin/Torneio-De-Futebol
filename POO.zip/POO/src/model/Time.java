package model;

import java.util.ArrayList;
import java.util.List;


public class Time {
    
    private String nome;
    private int rankingCMD;
    private int pontos;
    
    public Time(String nome, int rankingCMD) {
        this.nome = nome;
        this.rankingCMD = rankingCMD;
        this.pontos = 0; 
    }

    public void adicionarPontos(int valor) {
        this.pontos += valor;
    }

    // Getters para acessar os dados no Torneio e Partida
    public String getNome() { return nome; }
    public int getPontos() { return pontos; }
    public int getRankingCMD() { return rankingCMD; }
}