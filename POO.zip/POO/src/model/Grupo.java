package model;

import java.util.ArrayList;
import java.util.List;

public class Grupo {

    private String nome;
    private List<Time> participantes;


    public Grupo(String nome){
        
        this.nome = nome;
        this.participantes = new ArrayList<>();

    }

}

private Grupo cabecaChave(String nome, List<Time>){

}