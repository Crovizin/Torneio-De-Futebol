package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Partida {
    
    private Time timeCasa;
    private Time timeVisitante;
    private int golCasa;
    private int golVisitante;

    public Partida(Time timeCasa, Time timeVisitante) {
        this.timeCasa = timeCasa;
        this.timeVisitante = timeVisitante;
    }

    public void simularPartida() {
        Random random = new Random();
        this.golCasa = random.nextInt(6); 
        this.golVisitante = random.nextInt(6);

        if (this.golCasa > this.golVisitante) {
            timeCasa.adicionarPontos(3); // Vitória é 3 pontos 
            timeVisitante.adicionarPontos(-1); // Derrota subtrai 1 ponto 
        } else if (this.golCasa == this.golVisitante) {
            timeCasa.adicionarPontos(1); // Empate soma 1 ponto [cite: 28]
            timeVisitante.adicionarPontos(1);
        } else {
            timeVisitante.adicionarPontos(3);
            timeCasa.adicionarPontos(-1);
        }
    }
}