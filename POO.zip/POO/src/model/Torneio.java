package model;

import java.util.ArrayList;
import java.util.List;


public class Torneio {

    private List<Time> todosTimes;
    private List<Grupo> grupos;

    {

        this.todosTimes = new ArrayList<>();
        this.grupos = new ArrayList<>();

    }

}
